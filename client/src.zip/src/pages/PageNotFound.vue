<template>
    <div class="page-not-found">
        <h1 class="title">Page Not Found 404</h1>
    </div>
</template>

<script>
    export default {
        name: "PageNotFound"
    }
</script>

<style lang="scss" scoped>
.page-not-found {
    height: 1000px;
}
.title {
    position: absolute;
    top: 50%;
    right: 40%;
    text-transform: uppercase;
}
</style>