<template>
    <div>
        <h1>Product Detail PAge</h1>
    </div>
</template>

<script>
    export default {
        name: "ProductDetailPage"
    }
</script>

<style lang="scss" scoped>

</style>