<template>
    <div>
        <h1>Shopping Cart Page</h1>
    </div>
</template>

<script>
    export default {
        name: "ShoppingCartPage",
    }
</script>

<style lang="scss" scoped>

</style>