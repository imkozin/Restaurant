<template>
  <h1>Burgerovich</h1>
  <div class="page-wrap">
    <router-view></router-view>
  </div>
</template>

<style lang="scss">

</style>
